A Pen created at CodePen.io. You can find this one at https://codepen.io/theonig/pen/XpjPJZ.

 a plugin that has an area where the quotes appeared, a botton which when you push it will show a new random quote and some social media bottons with them you can shre your quotes with your friends!
